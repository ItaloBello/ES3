// const dropAgend = document.getElementById('opt-agendamento');
// const dropCamp  = document.getElementById('opt-campeonato')
// const dropQuad = document.getElementById('opt-quadras')

// function showOpts(){
//     dropAgend.style.display = "flex";
//     dropAgend.style.flexdirection = "column";
// }